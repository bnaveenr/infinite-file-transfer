import java.io.*;
import java.net.*;




public class client1
{








	public static void main( String args[] )
	 {
		  if (args.length != 3)
		  {
					System.err.println(
						"Usage: java client1 <host name> <port no> <name of file>");
					System.exit(1);
		  }
		  try
		  {
			          byte buffer[] = new byte[25] ;  //256
			          String hostName = args[0];
			          String nameOfFile = args[2];
			          String lineStr ;
                      int port ;
                      port = Integer.parseInt( args[1] ) ;
		              Socket echoSocket = new Socket(hostName, port );
		              PrintWriter out =
		                  new PrintWriter(echoSocket.getOutputStream(), true);

		              InputStream in =   echoSocket.getInputStream() ;

                      //Send the file name
                      out.print(nameOfFile) ; out.flush() ;
                      System.out.println( "Sent the name of the file." ) ;

                      FileOutputStream Outf = new FileOutputStream(nameOfFile);

                      int noRead = 0 ;
                       while(   (noRead=in.read(buffer, 0, 25)) > 0 )
                       {

                          System.out.println("noRead=" + noRead ) ;
                          Outf.write(buffer, 0 , noRead ) ;
      ;
					   }

                      Outf.close() ;




         }
        catch (UnknownHostException e)
        {
		              System.err.println("Don't know about host " );
		              System.exit(1);
		}
		catch (IOException e)
		{
		              System.err.println("Couldn't get I/O for the connection to " );
		              System.exit(1);
        }
		catch (Exception excep)
		{
		              System.err.println(excep.toString() )  ;
		              excep.printStackTrace() ;
		              System.exit(1);
        }



	 }





}
