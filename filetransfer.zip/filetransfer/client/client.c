#include	"unp1.h"
#include    <errno.h>

//-------------------------------------------------------------------------------------


void err_quitcs515(const char* messg, ...)
{
  printf( messg ) ;
  exit(1) ;
}

//-------------------------------------------------------------------------------------

void err_syscs515(const char* messg, ... )
{
  printf( messg ) ;
  exit(1) ;
}

//-------------------------------------------------------------------------------------

int
main(int argc, char **argv)
{
	int					sockfd, n;
	int no1 ;
	char				recvline[MAXLINE + 1];
	char				filename[MAXLINE + 1];
	struct sockaddr_in	servaddr;
	FILE* fp1  ;
	int port ;

	if (argc != 4)
	 {
		printf("usage: client.exe <IPaddress> <port> <fileNameToFetch>");
	}

	if(sscanf(argv[2], "%d", &port) == EOF)
	{
	    fprintf(stderr, "WARNING: Incorrect value for port number\n");
	    return 0;
    }


	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		err_syscs515("socket error");

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port   = htons(port);	/* daytime server */
	if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
	  err_quitcs515("inet_pton error for %s", argv[1]);

	if (connect(sockfd, (SA *) &servaddr, sizeof(servaddr)) < 0)
		printf("Connect error: %s" , strerror( errno ) );

    //first send the file name
    printf( "Sending the filename: %s\n" , argv[3] ) ;
    no1 = write(sockfd, argv[3], strlen(argv[3])  ) ;

    if ( no1 < 0 )
    {
	  printf( "Error in sending the filename from the client: %s ", strerror( errno ) ) ;
	}

    //now read from the socket and write to file


    fp1 =   fopen(argv[3], "w") ;

    printf( "Before reading the file.\n" ) ;
    int noWritten ;
	while ( (no1 = read(sockfd, recvline, MAXLINE)) > 0)
	{

        noWritten = fwrite(recvline,1, no1, fp1   ) ;
        if ( noWritten == -1 )
         {
            printf( "Error writing to the file %s\n" , strerror( errno ) ) ;
            exit(0) ;
		 }
		else
		 printf( "Wrote %d to the file.\n" , noWritten ) ;

	}
   //close file pointer
   fclose( fp1 ) ;



	exit(0);
}
