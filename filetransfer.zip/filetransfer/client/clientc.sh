rm client.exe
gcc client.c -o client.exe
