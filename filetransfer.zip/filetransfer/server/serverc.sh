rm server.exe
gcc server.c -o server.exe
