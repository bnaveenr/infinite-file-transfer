#include	"unp1.h"
#include	<time.h>
#include    <errno.h>

//----------------------------------------------------------------------------------------------
//Start the server program
// ./server.exe portno
//----------------------------------------------------------------------------------------------

int process( int sockfd )
{
  char recvline[MAXLINE] ; int noRead ;
  int nread ; int no1 ;
  FILE *fp1 ;

  printf( "Begin read.\n" ) ;
  noRead = read(sockfd, recvline, MAXLINE) ;
  //printf( "End read. %d %d\n", recvline[noRead-1], recvline[noRead-1] ) ;

  if ( noRead < 0 )
    {
	  printf( "Error in reading the filename from the client: %s \n", strerror( errno ) ) ;
	  return(0) ;
	}
  else
    {  //java program
  	   //if ( recvline[noRead-2] == '\n' )
	   //  recvline[noRead-2] = 0 ;	/* null terminate */
	   //else
         recvline[noRead] = 0 ;	/* null terminate */
         printf("%s\n" , recvline ) ;

    }

  printf( "After read: %d bytes, -%s-\n" , noRead, recvline ) ;

  //now read from the file and send the bytes to the client.
  fp1 =   fopen(recvline, "rb");
   if (!fp1 )
   {
	   printf("Couldn't open file %s for reading. (%s) %s\n", recvline, strerror( errno ) );
	   return 0;
   }

   int total = 0 ;
    /* Seek to the beginning of the file */
   fseek(fp1, SEEK_SET, 0);


   while (   (nread=fread(recvline,1,MAXLINE-1, fp1 )) > 0 )
      {
          if (nread > 0)
           {

			    printf( "Server read %d bytes.\n", nread ) ;
				no1 = write(sockfd, recvline, nread  ) ;
				if ( no1 < 0  || nread != no1 )
				{
				  printf( "Error in sending data from the server: %s \n", strerror( errno ) ) ;
				  exit(0) ;
				}
				else
				 total += no1 ;
				//recvline[nread] = 0 ;

				 printf( "Sent %d bytes of %d. Total %d\n", no1 , nread, total) ;



		   } //if


      } //while

   //close file pointer
   fclose( fp1 ) ;

  return ( 1) ;
}

//----------------------------------------------------------------------------------------------

int main(int argc, char **argv)
{
	int					listenfd, connfd;
	struct sockaddr_in	servaddr;
	char				buff[MAXLINE];
	time_t				ticks;
    int port ;
    printf( "Inside server main.\n" ) ;
	listenfd = socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	if (argc != 2)
	{
		printf("usage: server.exe portno\n");
		return(0) ;
	}

	if(sscanf(argv[1], "%d", &port) == EOF)
	{
	    fprintf(stderr, "WARNING: Incorrect value for device\n");
	    return 0;
    }
    printf( "Post specified as: %d\n" , port ) ;
	servaddr.sin_port      = htons(port);	/* daytime server */

	if ( bind(listenfd, (SA *) &servaddr, sizeof(servaddr)) < 0 )
	  {
        printf( "Bind error %s\n" , strerror( errno ) ) ;
        return(0) ;
	  }

	listen(listenfd, LISTENQ);

	for ( ; ; ) {
		printf( "Before accepting a connection.\n" ) ;
		connfd = accept(listenfd, (SA *) NULL, NULL);
		printf( "After accepting a connection.\n" ) ;
        process( connfd ) ;


		close(connfd);
	}
}

//----------------------------------------------------------------------------------------------
